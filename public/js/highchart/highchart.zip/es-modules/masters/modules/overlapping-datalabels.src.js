/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/modules/overlapping-datalabels
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/overlapping-datalabels.src.js';
